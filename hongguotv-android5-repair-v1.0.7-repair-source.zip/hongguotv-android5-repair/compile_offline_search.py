# SPDX-License-Identifier: GPL-3.0-only
"""Compile only the search helper, then canonicalize the patched APK DEX with local D8."""
from pathlib import Path
import subprocess,zipfile,sys,os

from toolchain import ROOT, JAVA, ANDROID_SDK as SDK, BUILD_TOOLS, BASE, verify_base
verify_base()
work=ROOT/'offline-search/build';work.mkdir(exist_ok=True)
stubs=work/'stubs';stubs.mkdir(exist_ok=True)
classes=work/'classes';classes.mkdir(exist_ok=True)
definitions={
 'Series':'public class Series { public Series(String a,String b,String c,String d,String e,String f) {} public String getId(){return null;} }',
 'ComicRanking':'public class ComicRanking {}',
 'ContentType':'public enum ContentType { SHORT, COMIC }',
 'CatalogPage':'public class CatalogPage { public CatalogPage(java.util.List<Series> a,boolean b,ComicRanking c) {} }'
}
for name,body in definitions.items():(stubs/(name+'.java')).write_text('package com.hongguotv.core;\n'+body)
android=SDK/'platforms/android-36/android.jar'
command=[str(JAVA/'bin/javac'),'--release','8','-encoding','UTF-8','-g:none','-classpath',str(android),'-d',str(classes)]
command += [str(p) for p in stubs.glob('*.java')]+[str(ROOT/'offline-search/SearchRepair.java')]
r=subprocess.run(command,capture_output=True,text=True);print('Search helper compilation',r.returncode,flush=True)
if r.returncode:print(r.stderr[-5000:]);raise SystemExit(r.returncode)
jar=work/'search-helper.jar'
with zipfile.ZipFile(jar,'w',zipfile.ZIP_DEFLATED) as archive:
 for p in classes.glob('com/hongguotv/core/SearchRepair*.class'):archive.write(p,str(p.relative_to(classes)))
sys.path.insert(0,str(ROOT/'offline-search'));from patch_dex import patch,replace_string,strings
inputs=work/'dex-input';inputs.mkdir(exist_ok=True);patched=[];paths=[]
with zipfile.ZipFile(BASE) as archive:
 for name in archive.namelist():
  if name.endswith('.dex'):
   data,changed=patch(archive.read(name));p=inputs/name;p.write_bytes(data);paths.append(str(p))
   if changed:patched.append(name)
assert len(patched)==1,patched;print('Redirected one search method in',patched[0],flush=True)
out=work/'canonical-dex';out.mkdir(exist_ok=True)
for p in out.glob('*.dex'):p.unlink()
command=[str(JAVA/'bin/java'),'-Xmx3g','-cp',str(BUILD_TOOLS/'lib/d8.jar'),'com.android.tools.r8.D8',
 '--release','--min-api','21','--lib',str(android),'--output',str(out),str(inputs/patched[0]),str(jar)]
r=subprocess.run(command,capture_output=True,text=True)
(work/'d8.log').write_text(r.stdout+r.stderr)
print('D8 canonicalization',r.returncode,flush=True)
if r.returncode:print((r.stdout+r.stderr)[:3500]);raise SystemExit(r.returncode)
generated=list(out.glob('*.dex'));assert len(generated)==1
repaired=generated[0].read_bytes()
for p in generated:p.unlink()
for path in paths:
 p=Path(path);(out/p.name).write_bytes(repaired if p.name==patched[0] else p.read_bytes())
print('Validated DEX output',len(list(out.glob('*.dex'))),'files',flush=True)
for path in paths:
    source=Path(path);updated=(out/source.name).read_bytes();changed=False
    original_text,_=strings(updated)
    replacements=[('名称或关键词','或其他剧名（综合搜索）')]+[(value,value.replace('1.0.6','1.0.7-repair')) for value in original_text if '1.0.6' in value]
    for old,new in replacements:
        updated,replaced=replace_string(updated,old,new);changed=changed or replaced
    if not changed:continue
    temp=work/'hint-input.dex';temp.write_bytes(updated)
    hintout=work/'hint-output';hintout.mkdir(exist_ok=True)
    for item in hintout.glob('*.dex'):item.unlink()
    command=[str(JAVA/'bin/java'),'-Xmx1g','-cp',str(BUILD_TOOLS/'lib/d8.jar'),'com.android.tools.r8.D8',
        '--release','--min-api','21','--lib',str(android),'--output',str(hintout),str(temp)]
    r=subprocess.run(command,capture_output=True,text=True)
    if r.returncode:print(r.stderr[:2000]);raise SystemExit(r.returncode)
    generated=list(hintout.glob('*.dex'));assert len(generated)==1
    (out/source.name).write_bytes(generated[0].read_bytes());print('Combined-search hint updated in',source.name,flush=True)
