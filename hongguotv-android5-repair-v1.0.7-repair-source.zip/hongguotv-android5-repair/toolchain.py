# SPDX-License-Identifier: GPL-3.0-only
"""Explicit local toolchain; this module never downloads dependencies."""
from pathlib import Path
import hashlib
import os

ROOT = Path(__file__).resolve().parent
BASE = ROOT / 'inputs' / 'original-hongguotv-1.0.6.apk'
BASE_SHA256 = 'bceec35fcbc54b8b9f99ab53229f0843533c66efb4c47a178221d4a5ceb4d268'


def required_directory(*names):
    value = next((os.environ[name] for name in names if os.environ.get(name)), None)
    if not value or not Path(value).is_dir():
        raise SystemExit('Set ' + ' or '.join(names) + ' to an existing toolchain directory.')
    return Path(value).resolve()


JAVA = required_directory('JAVA_HOME')
ANDROID_SDK = required_directory('ANDROID_SDK_ROOT', 'ANDROID_HOME')
BUILD_TOOLS = ANDROID_SDK / 'build-tools' / '36.0.0'
for path in [JAVA / 'bin/java', JAVA / 'bin/javac', JAVA / 'bin/keytool',
             ANDROID_SDK / 'platforms/android-36/android.jar',
             BUILD_TOOLS / 'lib/d8.jar', BUILD_TOOLS / 'lib/apksigner.jar',
             BUILD_TOOLS / 'zipalign']:
    if not path.is_file():
        raise SystemExit('Missing required tool: ' + str(path))


def verify_base():
    if not BASE.is_file():
        raise SystemExit('Missing build input; run python3 fetch_base.py first.')
    if hashlib.sha256(BASE.read_bytes()).hexdigest() != BASE_SHA256:
        raise SystemExit('Base APK SHA-256 mismatch; refusing to patch.')
