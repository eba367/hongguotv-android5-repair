"""Prepare a D8 input: redirect one method to the separately compiled search helper.

Intermediate tables are relocated without altering existing indices. D8 canonicalizes all
tables and validates instructions before any output is placed in an installable APK.
"""
import struct,hashlib,zlib

def uleb(b,p):
    value=0;shift=0
    while True:
        x=b[p];p+=1;value|=(x&127)<<shift
        if not x&128:return value,p
        shift+=7
def put_uleb(v):
    out=bytearray()
    while v>=128:out.append((v&127)|128);v>>=7
    out.append(v);return bytes(out)
def strings(b):
    count,offset=struct.unpack_from('<II',b,56);out=[];positions=[]
    for i in range(count):
        pos=struct.unpack_from('<I',b,offset+i*4)[0];positions.append(pos);_,p=uleb(b,pos)
        end=b.index(0,p);out.append(bytes(b[p:end]).decode('utf-8','replace'))
    return out,positions

def replace_string(data,old,new):
    b=bytearray(data);text,offsets=strings(b)
    if old not in text:return data,False
    index=text.index(old);offsets[index]=len(b)
    b+=put_uleb(len(new.encode('utf-16le'))//2)+new.encode()+b'\0'
    b+=b'\0'*((-len(b))%4);string_table=len(b)
    b+=b''.join(struct.pack('<I',v) for v in offsets)
    mapoff=struct.unpack_from('<I',b,52)[0];count=struct.unpack_from('<I',b,mapoff)[0]
    entries=[list(struct.unpack_from('<HHII',b,mapoff+4+i*12)) for i in range(count)]
    b+=b'\0'*((-len(b))%4);newmap=len(b)
    for entry in entries:
        if entry[0]==1:entry[3]=string_table
        elif entry[0]==0x2002:entry[2]+=1
        elif entry[0]==0x1000:entry[3]=newmap
    entries.sort(key=lambda e:e[3]);b+=struct.pack('<I',count)+b''.join(struct.pack('<HHII',*e) for e in entries)
    struct.pack_into('<I',b,60,string_table);struct.pack_into('<I',b,52,newmap);struct.pack_into('<I',b,32,len(b))
    struct.pack_into('<I',b,104,len(b)-struct.unpack_from('<I',b,108)[0])
    b[12:32]=hashlib.sha1(b[32:]).digest();struct.pack_into('<I',b,8,zlib.adler32(b[12:])&0xffffffff)
    return bytes(b),True

def patch(data):
    b=bytearray(data);text,string_offsets=strings(b)
    nt,to=struct.unpack_from('<II',b,64);types=list(struct.unpack_from('<'+'I'*nt,b,to))
    try:target=types.index(text.index('Lcom/hongguotv/core/ContentRepository;'))
    except ValueError:return data,False
    nm,mo=struct.unpack_from('<II',b,88);methods=[struct.unpack_from('<HHI',b,mo+i*8) for i in range(nm)]
    method=next((i for i,m in enumerate(methods) if m[0]==target and text[m[2]]=='search'),None)
    if method is None:return data,False
    nc,co=struct.unpack_from('<II',b,96);class_data=None
    for i in range(nc):
        off=co+i*32
        if struct.unpack_from('<I',b,off)[0]==target:class_data=struct.unpack_from('<I',b,off+24)[0];break
    if class_data is None:return data,False
    p=class_data;counts=[]
    for _ in range(4):v,p=uleb(b,p);counts.append(v)
    for _ in range(counts[0]+counts[1]):_,p=uleb(b,p);_,p=uleb(b,p)
    code=None
    for count in counts[2:]:
        index=0
        for _ in range(count):
            delta,p=uleb(b,p);index+=delta;_,p=uleb(b,p);offset,p=uleb(b,p)
            if index==method:code=offset
    assert code and nm<65535
    registers,ins,outs,tries=struct.unpack_from('<HHHH',b,code);assert ins==4
    struct.pack_into('<HHII',b,code+4,3,0,0,5)
    struct.pack_into('<HHHHH',b,code+16,0x377,nm,registers-3,0x000c,0x0011)
    added_strings=0
    # Tell users that the restored public search combines both catalogue types.
    for i,value in enumerate(text):
        if value=='名称或关键词':
            value='或其他剧名（综合搜索）';string_offsets[i]=len(b)
            raw=value.encode();b+=put_uleb(len(value.encode('utf-16le'))//2)+raw+b'\0';added_strings+=1
    descriptor='Lcom/hongguotv/core/SearchRepair;';string_offsets.append(len(b))
    b+=put_uleb(len(descriptor))+descriptor.encode()+b'\0';added_strings+=1
    def align():b.extend(b'\0'*((-len(b))%4))
    align();new_so=len(b);b+=b''.join(struct.pack('<I',x) for x in string_offsets)
    align();new_to=len(b);b+=b''.join(struct.pack('<I',x) for x in types+[len(text)])
    align();new_mo=len(b);b+=data[mo:mo+nm*8]+struct.pack('<HHI',nt,methods[method][1],methods[method][2])
    old_map=struct.unpack_from('<I',b,52)[0];map_count=struct.unpack_from('<I',b,old_map)[0];maps=[]
    align();new_map=len(b)
    for i in range(map_count):
        kind,unused,count,offset=struct.unpack_from('<HHII',b,old_map+4+i*12)
        if kind==1:count,offset=len(string_offsets),new_so
        elif kind==2:count,offset=nt+1,new_to
        elif kind==5:count,offset=nm+1,new_mo
        elif kind==0x1000:offset=new_map
        elif kind==0x2002:count+=added_strings
        maps.append((kind,unused,count,offset))
    maps.sort(key=lambda x:x[3]);b+=struct.pack('<I',len(maps))+b''.join(struct.pack('<HHII',*m) for m in maps)
    struct.pack_into('<II',b,56,len(string_offsets),new_so);struct.pack_into('<II',b,64,nt+1,new_to)
    struct.pack_into('<II',b,88,nm+1,new_mo);struct.pack_into('<I',b,52,new_map);struct.pack_into('<I',b,32,len(b))
    data_off=struct.unpack_from('<I',b,108)[0];struct.pack_into('<I',b,104,len(b)-data_off)
    b[12:32]=hashlib.sha1(b[32:]).digest();struct.pack_into('<I',b,8,zlib.adler32(b[12:])&0xffffffff)
    return bytes(b),True
