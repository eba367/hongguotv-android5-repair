// SPDX-License-Identifier: GPL-3.0-only
package com.hongguotv.core;

import java.io.*;
import java.net.*;
import java.util.*;
import java.util.zip.GZIPInputStream;
import org.json.*;

/** A narrowly scoped, account-free replacement for the retired search endpoint. */
public final class SearchRepair {
    private static final LinkedHashMap<String,List<Series>> pages=new LinkedHashMap<String,List<Series>>();
    private static String str(JSONObject o,String key) { return o.isNull(key)?"":o.optString(key,"").trim(); }
    private static String normal(String s) { return s.toLowerCase(Locale.ROOT).replaceAll("[\\p{P}\\p{Z}\\s]",""); }
    private static JSONObject get(String path) throws Exception {
        HttpURLConnection c=(HttpURLConnection)new URL("https://hongguoduanju.com"+path).openConnection();
        c.setConnectTimeout(8000);c.setReadTimeout(10000);
        c.setRequestProperty("Accept","application/json");c.setRequestProperty("Accept-Encoding","identity");
        c.setRequestProperty("User-Agent","Mozilla/5.0 (Linux; Android TV) HongguoTV/1.0.7");
        try {
            int status=c.getResponseCode();
            if(status!=200) throw new IOException("搜索服务暂不可用（HTTP "+status+"）");
            InputStream input=c.getInputStream();
            if("gzip".equalsIgnoreCase(c.getContentEncoding()))input=new GZIPInputStream(input);
            ByteArrayOutputStream out=new ByteArrayOutputStream();
            try {
                byte[] buffer=new byte[8192];int n;
                while((n=input.read(buffer))!=-1) {
                    if(Thread.currentThread().isInterrupted())throw new InterruptedIOException("搜索已取消");
                    out.write(buffer,0,n);
                    if(out.size()>2*1024*1024)throw new IOException("搜索响应过大");
                }
            } finally { input.close(); }
            if(out.size()==0)throw new IOException("搜索服务响应为空");
            return new JSONObject(new String(out.toByteArray(),"UTF-8"));
        } finally { c.disconnect(); }
    }
    private static void collect(JSONArray rows,boolean suggestions,String query,LinkedHashMap<String,Series> found) {
        for(int i=0;i<rows.length();i++) {
            JSONObject row=rows.optJSONObject(i);if(row==null)continue;
            JSONObject o=row.optJSONObject("video_data");if(o==null)continue;
            int count=o.optInt("episode_cnt",0);
            JSONObject episodeInfo=o.optJSONObject("series_episode_info");
            if(count==0 && episodeInfo!=null)count=episodeInfo.optInt("episode_cnt",0);
            if(suggestions && (!"short_play_name".equals(str(row,"word_type")) || count<=0))continue;
            String id=str(o,"series_id");String title=str(o,"series_name");
            if(title.length()==0)title=str(o,"series_title");if(title.length()==0)title=str(row,"name");
            if(!id.matches("[0-9]{1,30}") || title.length()==0 || !normal(title).contains(query))continue;
            JSONArray tags=o.optJSONArray("tags");if(tags==null)tags=o.optJSONArray("category_list");
            StringBuilder tagText=new StringBuilder();
            if(tags!=null)for(int j=0;j<Math.min(tags.length(),5);j++) {
                if(j>0)tagText.append(" · ");JSONObject tag=tags.optJSONObject(j);
                tagText.append(tag==null?tags.optString(j):str(tag,"name"));
            }
            String cover=str(o,"series_cover").replace("\\/","/").replace("&amp;","&");
            String badge=str(o,"episode_right_text");if(badge.length()==0 && count>0)badge="全 "+count+" 集";
            found.put(id,new Series(id,title,cover,str(o,"series_intro"),"综合搜索"+(badge.length()==0?"":" · "+badge),tagText.toString()));
        }
    }
    public static synchronized CatalogPage search(String keyword,int page,ContentType ignored) throws IOException {
        String query=keyword.trim(),wanted=normal(query);
        if(wanted.length()==0)throw new IOException("请输入剧名或关键词");
        if(query.length()>30)throw new IOException("关键词最多30个字，请缩短后搜索");
        if(page<1 || page>100)throw new IOException("搜索页码无效");
        if(page==1) {
            Iterator<String> it=pages.keySet().iterator();while(it.hasNext())if(it.next().startsWith(query+"\n"))it.remove();
        }
        LinkedHashMap<String,Series> found=new LinkedHashMap<String,Series>();
        boolean answered=false,more=false;Exception failure=null;
        String encoded=URLEncoder.encode(query,"UTF-8");
        if(page==1)try {
            JSONObject data=get("/api/search/suggestion/?query="+encoded);
            JSONArray rows=data.optJSONArray("suggestionList");if(rows==null)throw new IOException("搜索建议格式已变化");
            collect(rows,true,wanted,found);answered=true;
        } catch(Exception e) { failure=e; }
        if(Thread.currentThread().isInterrupted())throw new InterruptedIOException("搜索已取消");
        try {
            JSONObject data=get("/api/search/result?query="+encoded+"&page="+page);
            JSONArray rows=data.optJSONArray("searchList");if(rows==null)throw new IOException("搜索结果格式已变化");
            collect(rows,false,wanted,found);more=data.optBoolean("hasMore",false) && page<100;answered=true;
        } catch(Exception e) { if(failure==null)failure=e; }
        if(!answered)throw new IOException("搜索服务未返回有效数据，请稍后重试",failure);
        Set<String> previous=new HashSet<String>();
        for(int n=1;n<page;n++) {
            List<Series> old=pages.get(query+"\n"+n);if(old!=null)for(Series s:old)previous.add(s.getId());
        }
        List<Series> result=new ArrayList<Series>();
        for(Map.Entry<String,Series> entry:found.entrySet())if(!previous.contains(entry.getKey()))result.add(entry.getValue());
        pages.put(query+"\n"+page,result);while(pages.size()>30)pages.remove(pages.keySet().iterator().next());
        return new CatalogPage(result,more,null);
    }
}
