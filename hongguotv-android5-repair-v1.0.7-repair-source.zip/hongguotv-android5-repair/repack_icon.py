# SPDX-License-Identifier: GPL-3.0-only
"""Replace launcher artwork without recompiling application code; sign a local APK."""
from pathlib import Path
import zipfile, struct, subprocess, json, os, secrets, sys, hashlib

from toolchain import ROOT, JAVA, BUILD_TOOLS as SDK, BASE, verify_base
verify_base()
PACKAGE='com.hongguotv.nativeapp'
TEST='--test' in sys.argv
SEARCH='--search' in sys.argv

def replace_manifest_strings(data, replacements):
    kind,header,total=struct.unpack_from('<HHI',data)
    assert kind==3
    pos=header
    while pos<len(data):
        ctype,chead,csize=struct.unpack_from('<HHI',data,pos)
        if ctype!=1:pos+=csize;continue
        count,styles,flags,start,style_start=struct.unpack_from('<IIIII',data,pos+8)
        assert styles==0,'Manifest styled strings are unsupported'
        utf8=bool(flags&256)
        def length(at):
            if utf8:
                n=data[at];return (((n&127)<<8)|data[at+1],at+2) if n&128 else (n,at+1)
            n=struct.unpack_from('<H',data,at)[0]
            return (((n&32767)<<16)|struct.unpack_from('<H',data,at+2)[0],at+4) if n&32768 else (n,at+2)
        strings=[]
        for i in range(count):
            at=pos+start+struct.unpack_from('<I',data,pos+chead+i*4)[0]
            chars,at=length(at)
            if utf8:
                size,at=length(at);text=data[at:at+size].decode('utf-8')
            else:text=data[at:at+chars*2].decode('utf-16le')
            strings.append(replacements.get(text,text))
        def encoded_length(n):
            if utf8:return bytes([(n>>8)|128,n&255]) if n>127 else bytes([n])
            return struct.pack('<HH',(n>>16)|32768,n&65535) if n>32767 else struct.pack('<H',n)
        pool=bytearray();offsets=[]
        for text in strings:
            offsets.append(len(pool));raw=text.encode('utf-8' if utf8 else 'utf-16le')
            pool+=encoded_length(len(text.encode('utf-16le'))//2)
            if utf8:pool+=encoded_length(len(raw))
            pool+=raw+(b'\0' if utf8 else b'\0\0')
        pool+=b'\0'*((-len(pool))%4)
        new_start=chead+count*4;new_size=new_start+len(pool)
        chunk=struct.pack('<HHIIIIII',1,chead,new_size,count,0,flags&~1,new_start,0)
        chunk+=b'\0'*(chead-len(chunk))+b''.join(struct.pack('<I',v) for v in offsets)+pool
        result=bytearray(data[:pos]+chunk+data[pos+csize:]);struct.pack_into('<I',result,4,len(result))
        return explicit_activity_artwork(bytes(result),strings)
    raise RuntimeError('Manifest string pool missing')

def explicit_activity_artwork(data,strings):
    """Some legacy TV launchers inspect activity artwork rather than application defaults."""
    chunks=[];pos=struct.unpack_from('<H',data,2)[0];artwork={};resource_ids=[]
    while pos<len(data):
        kind,head,size=struct.unpack_from('<HHI',data,pos);chunk=bytearray(data[pos:pos+size])
        if kind==0x180:resource_ids=list(struct.unpack_from('<'+'I'*((size-head)//4),chunk,head))
        if kind==0x102:
            ext=head;name=strings[struct.unpack_from('<I',chunk,ext+4)[0]]
            start,step,count,idindex,classindex,styleindex=struct.unpack_from('<HHHHHH',chunk,ext+8)
            attrs=[bytes(chunk[ext+start+i*step:ext+start+(i+1)*step]) for i in range(count)]
            if name=='manifest' and SEARCH:
                for i,a in enumerate(attrs):
                    if strings[struct.unpack_from('<I',a,4)[0]]=='versionCode':
                        a=bytearray(a);struct.pack_into('<I',a,16,17);attrs[i]=bytes(a)
                chunk[ext+start:ext+start+count*step]=b''.join(attrs)
            names={strings[struct.unpack_from('<I',a,4)[0]] for a in attrs}
            if name=='application':
                artwork={strings[struct.unpack_from('<I',a,4)[0]]:a for a in attrs if strings[struct.unpack_from('<I',a,4)[0]] in ['icon','banner']}
            if name=='activity':
                additions=[a for n,a in artwork.items() if n not in names]
                if additions:
                    assert (idindex,classindex,styleindex)==(0,0,0)
                    attrs+=additions
                    attrs.sort(key=lambda a:resource_ids[struct.unpack_from('<I',a,4)[0]])
                    tail=chunk[ext+start+count*step:]
                    chunk=chunk[:ext+start]+b''.join(attrs)+tail
                    struct.pack_into('<H',chunk,ext+12,len(attrs));struct.pack_into('<I',chunk,4,len(chunk))
        chunks.append(chunk);pos+=size
    result=bytearray(data[:8]+b''.join(chunks));struct.pack_into('<I',result,4,len(result));return bytes(result)

signing=ROOT/'signing';signing.mkdir(exist_ok=True);signing.chmod(0o700)
config_path=signing/'local-repair.json'
if config_path.exists():config=json.loads(config_path.read_text())
else:
    config={'keystore':'hongguo-repair.p12','alias':'hongguo-repair','password':secrets.token_urlsafe(28)}
    config_path.write_text(json.dumps(config));config_path.chmod(0o600)
config['keystore']=str(signing/Path(config['keystore']).name)
env=os.environ.copy();env['HG_REPAIR_STOREPASS']=config['password']
if not Path(config['keystore']).exists():
    subprocess.run([str(JAVA/'bin/keytool'),'-genkeypair','-noprompt','-keystore',config['keystore'],'-storetype','PKCS12',
        '-storepass:env','HG_REPAIR_STOREPASS','-keypass:env','HG_REPAIR_STOREPASS','-alias',config['alias'],
        '-keyalg','RSA','-keysize','2048','-validity','10000','-dname','CN=Hongguo Local Repair'],env=env,check=True,capture_output=True)
    Path(config['keystore']).chmod(0o600)
output=ROOT/'output';output.mkdir(exist_ok=True)
unsigned=output/'icon-unsigned.apk';aligned=output/'icon-aligned.apk'
with zipfile.ZipFile(BASE) as source,zipfile.ZipFile(unsigned,'w',zipfile.ZIP_DEFLATED) as target:
    for entry in source.infolist():
        name=entry.filename
        if name.startswith('META-INF/') and (name.upper().endswith(('.SF','.RSA','.DSA','.EC')) or name.upper()=='META-INF/MANIFEST.MF'):continue
        if name=='res/drawable/app_icon.xml' or (SEARCH and name.endswith('.dex')):continue
        data=source.read(entry)
        if name=='resources.arsc':
            old=b'res/drawable/app_icon.xml';new=b'res/drawable/app_icon.png'
            if old in data:data=data.replace(old,new)
            else:
                old=old.decode().encode('utf-16le');new=new.decode().encode('utf-16le')
                assert old in data;data=data.replace(old,new)
        if name=='res/drawable/tv_banner.png':data=(ROOT/'assets/android/tv_banner.png').read_bytes()
        if name=='AndroidManifest.xml':
            replacements={}
            if TEST:
                suffix='.repairtest' if SEARCH else '.icontest'
                replacements={PACKAGE:PACKAGE+suffix,PACKAGE+'.updates':PACKAGE+suffix+'.updates','红果 TV 原生版':'红果修复测试' if SEARCH else '红果图标测试'}
            elif SEARCH:replacements['红果 TV 原生版']='红果'
            if SEARCH:replacements['1.0.6']='1.0.7-repair'
            data=replace_manifest_strings(data,replacements)
        target.writestr(entry,data)
    target.write(ROOT/'assets/android/app_icon.png','res/drawable/app_icon.png')
    if SEARCH:
        dex=list((ROOT/'offline-search/build/canonical-dex').glob('*.dex'));assert dex
        for path in dex:target.write(path,path.name)
subprocess.run([str(SDK/'zipalign'),'-f','4',str(unsigned),str(aligned)],check=True,capture_output=True)
final=output/(('hongguo-1.0.7-repair-test.apk' if TEST else 'hongguo-1.0.7-repair.apk') if SEARCH else ('hongguo-icon-test.apk' if TEST else 'hongguo-1.0.6-new-icon.apk'))
subprocess.run([str(JAVA/'bin/java'),'-jar',str(SDK/'lib/apksigner.jar'),'sign','--ks',config['keystore'],'--ks-key-alias',config['alias'],
    '--ks-pass','env:HG_REPAIR_STOREPASS','--key-pass','env:HG_REPAIR_STOREPASS','--min-sdk-version','21','--out',str(final),str(aligned)],env=env,check=True,capture_output=True)
r=subprocess.run([str(JAVA/'bin/java'),'-jar',str(SDK/'lib/apksigner.jar'),'verify','--verbose',str(final)],check=True,capture_output=True,text=True)
print('\n'.join(line for line in r.stdout.splitlines() if line.startswith(('Verifies','Verified using','Number of signers'))))
print(final,hashlib.sha256(final.read_bytes()).hexdigest())
