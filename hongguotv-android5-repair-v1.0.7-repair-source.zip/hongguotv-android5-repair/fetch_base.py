# SPDX-License-Identifier: GPL-3.0-only
"""Fetch the pinned public upstream APK once; no automatic retries."""
from pathlib import Path
import hashlib
import urllib.request

root = Path(__file__).resolve().parent
target = root / 'inputs/original-hongguotv-1.0.6.apk'
expected = 'bceec35fcbc54b8b9f99ab53229f0843533c66efb4c47a178221d4a5ceb4d268'
url = 'https://github.com/flywingjie/hongguoTV/releases/download/v1.0.6/app-debug.apk'
if target.exists():
    if hashlib.sha256(target.read_bytes()).hexdigest() != expected:
        raise SystemExit('Existing input has an unexpected SHA-256; inspect it before replacing.')
    print('Pinned input already verified.')
else:
    target.parent.mkdir(exist_ok=True)
    temporary = target.with_suffix('.download')
    try:
        with urllib.request.urlopen(url, timeout=60) as source, temporary.open('wb') as output:
            size = 0
            while True:
                block = source.read(65536)
                if not block:
                    break
                size += len(block)
                if size > 32 * 1024 * 1024:
                    raise RuntimeError('Upstream input exceeds the expected size bound.')
                output.write(block)
        if hashlib.sha256(temporary.read_bytes()).hexdigest() != expected:
            raise RuntimeError('Downloaded APK SHA-256 mismatch.')
        temporary.replace(target)
        print('Pinned upstream APK downloaded and verified.')
    finally:
        temporary.unlink(missing_ok=True)
