# 构建说明

本次交付采用固定版本 APK 加定点补丁的构建方式，避免重新下载整套 Gradle 依赖。`upstream/` 是 flywingjie/hongguoTV **v1.0.6** 的完整未修改源码快照；实际新增代码在 `offline-search/`，实际打包入口是根目录两个 Python 脚本。

## 工具与步骤

已验证环境为 macOS、Python 3、JDK 17、Android SDK Platform 36、Build Tools 36.0.0。Linux 可使用对应平台工具；Windows 原生路径和工具扩展名尚未适配。

先安装好工具，设置自己的路径（脚本不下载工具）：

```sh
export JAVA_HOME=/path/to/jdk17
export ANDROID_SDK_ROOT=/path/to/android-sdk
python3 fetch_base.py
python3 compile_offline_search.py
python3 repack_icon.py --search
```

输出为 `output/hongguo-1.0.7-repair.apk`。首次打包在 `signing/` 生成自己的签名私钥和密码配置，请自行备份并保持私密。自行构建的签名与本仓库 Release 签名不同，无法直接覆盖安装官方发布包或本仓库发布包；以后保留同一私钥才能升级自己的构建。

`fetch_base.py` 只访问固定的 [flywingjie v1.0.6 APK](https://github.com/flywingjie/hongguoTV/releases/download/v1.0.6/app-debug.apk)，校验 SHA-256 后才落盘；网络失败即退出，不自动重试。也可自行把同一原包放到 `inputs/original-hongguotv-1.0.6.apk`，后续脚本仍会校验。

原包 SHA-256：`bceec35fcbc54b8b9f99ab53229f0843533c66efb4c47a178221d4a5ceb4d268`。

## 补丁流程

1. 用 `javac --release 8` 编译 `SearchRepair.java`。少量编译占位类仅用于匹配原包接口，不打入 APK。
2. 将原包 `ContentRepository.search` 重定向到新辅助类。通过 D8 规范化被修改的 DEX，其他无关 DEX 保留；相关提示与版本字符串也经 D8 处理。
3. 替换 PNG 图标、TV banner，更新二进制 manifest 的名称、版本及 Activity 图标属性。
4. 使用 `zipalign` 与 `apksigner` 对齐、签名并验证。脚本打印最终文件 SHA-256。

发布包使用了维护者独立签名，不公开私钥；ZIP 元数据和签名也会影响散列，因此自行构建的整个 APK 不会与发布包逐字节相同。可比较解压后的 DEX、manifest 和资源来验证补丁内容。

## 上游源码

源码快照对应提交：`e715d6b6178e8845e0afb08e2aab171e9cb1f569`。

`upstream/kotlin-tv/` 保留 Gradle wrapper、测试、许可证和上游构建说明。单独运行上游 Gradle 工程只会生成 **v1.0.6 原版**；它不会自动应用本目录的搜索与图标补丁。若改用完整 Kotlin 编译方案，需要另行移植并实测，不能把原版构建当作本版。

搜索访问 `hongguoduanju.com/api/search/suggestion/` 和 `/api/search/result`，只发送关键词、页码及通用请求头。服务域名不等于本项目运营的服务，也不构成长期可用承诺。

本构建流程没有添加自动播放设备登记，亦不应嵌入他人的播放身份或应用备份。
